"""Promptfoo Python provider for the baseline financial-report agent."""

from functools import lru_cache, partial
from pathlib import Path
from time import perf_counter
from typing import Any

import httpx
import psycopg
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from pydantic import AliasChoices, Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from agents.baseline.baseline_agent import BaselineAgent
from agents.settings import AgentConfig
from agents.tools import BaselineRetrieverAdapter, DatabaseCoverage, PgVectorRetriever
from etl.companies import COMPANY_TABLES
from etl.settings import DEFAULT_DATABASE_URL
from evals.telemetry import RunMetrics, record_embedding_response
from utils import normalize_optional_string, require_nonblank_string

_REPOSITORY_ROOT = Path(__file__).resolve().parents[1]


class ProviderSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=_REPOSITORY_ROOT / ".env",
        env_file_encoding="utf-8",
        env_prefix="EVAL_",
        extra="ignore",
    )

    openai_api_key: SecretStr = Field(validation_alias="OPENAI_API_KEY")
    database_url: str = Field(
        default=DEFAULT_DATABASE_URL,
        validation_alias=AliasChoices("EVAL_DATABASE_URL", "DATABASE_URL"),
    )
    chat_model: str = "gpt-6.1-terra"
    embedding_model: str = "text-embedding-3-small"
    embedding_dimensions: int = Field(default=1536, gt=0)
    retrieval_limit: int = Field(default=8, gt=0, le=100)
    max_retrieval_attempts: int = Field(default=3, gt=0)

    @field_validator("openai_api_key", mode="before")
    @classmethod
    def normalize_api_key(cls, value: object) -> object:
        value = normalize_optional_string(value)
        if value is None:
            raise ValueError("openai_api_key is required")
        return require_nonblank_string(value, field_name="openai_api_key")

    @field_validator("database_url", "chat_model", "embedding_model")
    @classmethod
    def require_nonblank_string(cls, value: str) -> str:
        return require_nonblank_string(value)


def build_agent(settings: ProviderSettings) -> BaselineAgent:
    """Wire the model, embeddings, pgvector retrieval, and baseline workflow."""

    api_key = settings.openai_api_key.get_secret_value()
    agent_config = AgentConfig(model=settings.chat_model)
    model = ChatOpenAI(model=agent_config.model, api_key=api_key)
    embeddings = OpenAIEmbeddings(
        model=settings.embedding_model,
        dimensions=settings.embedding_dimensions,
        api_key=api_key,
        http_client=httpx.Client(event_hooks={"response": [record_embedding_response]}),
    )
    retrievers = {
        company: PgVectorRetriever(
            embeddings=embeddings,
            connection_factory=partial(psycopg.connect, settings.database_url),
            limit=settings.retrieval_limit,
            company=company,
        )
        for company in COMPANY_TABLES
    }
    adapter = BaselineRetrieverAdapter(retrievers=retrievers)  # ty: ignore[invalid-argument-type]
    return BaselineAgent(
        model,  # ty: ignore[invalid-argument-type]
        retriever=adapter,
        max_retrieval_attempts=settings.max_retrieval_attempts,
        config=agent_config,
        coverage=DatabaseCoverage(connection_factory=partial(psycopg.connect, settings.database_url)),
    )


@lru_cache(maxsize=1)
def get_agent() -> BaselineAgent:
    """Cache expensive model, graph, embeddings, and retriever construction."""

    return build_agent(ProviderSettings())


def call_api(prompt: object, options: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
    """Translate Promptfoo's provider contract to baseline output and trajectory metadata."""

    del options, context
    prompt = require_nonblank_string(prompt, field_name="prompt")

    started = perf_counter()
    with RunMetrics() as metrics:
        result = get_agent().invoke(prompt)
    latency_ms = (perf_counter() - started) * 1000
    usage = metrics.metadata()
    return {
        "output": result.answer,
        "metadata": {
            "status": result.status,
            "citations": list(result.citations),
            "retrieval_attempts": result.retrieval_attempts,
            "tool_calls": list(getattr(result, "tool_calls", ())),
            "answer_latency_ms": latency_ms,
            "telemetry": usage,
        },
        "tokenUsage": {
            "prompt": usage["input_tokens"],
            "completion": usage["output_tokens"],
            "total": usage["total_tokens"],
            "cached": usage["cached_input_tokens"],
            "numRequests": usage["model_calls"],
        },
    }
